vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|28 Oct 2011 23:24:18 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{884E956D-14DC-4E06-944F-57C728E9A3FF}
vti_cacheddtm:TX|28 Oct 2011 23:24:18 -0000
vti_filesize:IR|7391
vti_backlinkinfo:VX|
