<?php
session_start();
$_SESSION['msgtype'] = $_POST['MessageType'];
$_SESSION['subject'] = $_POST['Subject'];
$_SESSION['subjectother'] = $_POST['SubjectOther'];
$_SESSION['comments'] = $_POST['Comments'];
$_SESSION['username'] = $_POST['Username'];
$_SESSION['useremail'] = $_POST['UserEmail'];
$_SESSION['usertel'] = $_POST['UserTel'];
$_SESSION['userfax'] = $_POST['UserFAX'];
$_SESSION['priority'] = $_POST['Priority'];
?>
<html>
 <head>
  <title>Feedback Completed</title>
 </head>
 <body>
 <h2><font color="#FF0000"><span style="background-color: #FFFF9B">You Have Submitted the Following:</span></font></h2>
 <?php 
 /*
 echo '<b>Message Type : </b>'.$_SESSION['msgtype'].'<br />';
 if ($_SESSION['subject'] != '(Other)')//Only if other subject is chosen will it be displayed
 {
  echo '<b>Subject: </b>'.$_SESSION['subject'].'<br />';
 }
 else 
 {
  echo '<b>Other Subject: </b>'.$_SESSION['subjectother'].'<br />';
 }
 echo '<b>Comments: </b>'.$_SESSION['comments'].'<br />';
 echo '<b>Name: </b>'.$_SESSION['username'].'<br />';
 echo '<b>E-Mail: </b>'.$_SESSION['useremail'].'<br />';
 echo '<b>Telephone No: </b>'.$_SESSION['usertel'].'<br />';
 echo '<b>Fax: </b>'.$_SESSION['userfax'].'<br />';
 if (isset($_POST['ContactRequested'])) 
 {
    echo '<b>Contact Requested:</b> Yes.<br />';
  }
if($_SESSION['priority'] =='High')//To chosse color of priority
{
  echo '<b>Priority: <span style="background-color: #FF0000"><font color="#FFFFFF">High</font></span></b><br />';
}
if($_SESSION['priority'] =='Normal')//To chosse color of priority
{
  echo '<b>Priority: <span style="background-color: #00FF00"><font color="#FFFFFF">Normal</font></span></b><br />';
}
if($_SESSION['priority'] =='Low')//To chosse color of priority
{
  echo '<b>Priority: <span style="background-color: #0000FF"><font color="#FFFFFF">Low</font></span></b><br />';
}*/
 ?>
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="26%" height="347">
  <tr>
    <td width="60%" height="40"><b>&nbsp;Message Type:<b></td>
    <td width="60%" height="40"><?php  echo $_SESSION['msgtype']; ?></td>
  </tr>
  <tr>
  <?php if ($_SESSION['subject'] != '(Other)')
 {
  echo '<td width="60%" height="40"><b>&nbsp;Subject:</b></td>';
  echo '<td width="60%" height="40">'.$_SESSION['subject'].'</td>';
 }
 else 
 {
  
  echo '<td width="60%" height="40"><b>&nbsp;Other Subject:</b></td>';
  echo '<td width="60%" height="40">'.$_SESSION['subjectother'].'</td>';
 } ?>
  </tr>
    <td width="60%" height="40"><b>&nbsp;Comments:<b></td>
    <td width="60%" height="40"><?php echo $_SESSION['comments']; ?></td>
  
  <tr>
    <td width="60%" height="40"><b>&nbsp;Name:<b></td>
    <td width="60%" height="40"><?php echo $_SESSION['username']; ?></td>
  </tr>
  <tr>
    <td width="60%" height="40"><b>&nbsp;E-Mail:<b></td>
    <td width="60%" height="40"><?php echo $_SESSION['useremail']; ?></td>
  </tr>
  <tr>
    <td width="60%" height="40"><b>&nbsp;Telephone No:<b></td>
    <td width="60%" height="40"><?php echo $_SESSION['usertel']; ?></td>
  </tr>
  <tr>
    <td width="60%" height="40"><b>&nbsp;Fax:<b></td>
    <td width="60%" height="40"><?php echo $_SESSION['userfax']; ?></td>
  </tr>
  <?php 
  //This part is for adding a new row containing contact requested detail if The box was checked
  if (isset($_POST['ContactRequested']))
  {
  echo '<tr>';
    echo '<td width="60%" height="40"><b>&nbsp;Contact Requested:<b></td>';
    echo '<td width="60%" height="40">Yes</td>';
  echo '</tr>';
  }
  ?>
  <tr>
  <td width="60%" height="40"><b>&nbsp;Priority:<b></td>
  <td width="60%" height="40">
  <?php
  //to fill in the 2nd column cell with priority
    if($_SESSION['priority'] =='High')//To chosse color of priority
    {
      echo '<span style="background-color: #FF0000"><font color="#FFFFFF">High</font></span>';
    }
    if($_SESSION['priority'] =='Normal')//To chosse color of priority
    {
      echo '<span style="background-color: #00FF00"><font color="#FFFFFF">Normal</font></span>';
    }
    if($_SESSION['priority'] =='Low')//To chosse color of priority
    {
      echo '<span style="background-color: #0000FF"><font color="#FFFFFF">Low</font></span>';
    }
  ?>
  </td>
  </tr>
</table>
<hr>
<h5>The Cogia Corp. Wholly for&nbsp; the Students, by the Students.<br>
Copyright � 2010&nbsp; [Cogia connecting answers]. All rights reserved.</h5>
 </body>
</html>