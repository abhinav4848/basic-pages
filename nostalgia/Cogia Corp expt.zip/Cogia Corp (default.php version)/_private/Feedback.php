<?php
session_unset();
?>
<html>
<head>
<title>Feedback-Cogia</title>
<meta name="Microsoft Theme" content="none, default">
</head>

<body>
<h2 align="Center"><font color="#FF0000"><span style="background-color: #FFFF9B">Feedback Form</span></font></h2>
<p>Here is a place to send us all your valuable feedback to make us better. we 
welcome all your complaints, Problems, Suggestions, and of course. Praises You could mail your feedback to us on our <a title="abhinav4848@yahoo.co.in" style="text-decoration: none" href="mailto:abhinav4848@yahoo.co.in?subject=Feedback--"><u>e-mail</u></a>, 
Do not forget to mention after feedback in your subject what your feedback is 
about. &quot;Complaint/Problem/Suggestion/Praise&quot; </p>
<hr>
<p>Tell us what you think about our web site, our interface, our organization, 
or anything else that comes to mind. We welcome all of your comments and 
suggestions.</p>
<form method="POST" action="display.php">
  <p><strong>What kind of comment would you like to send?</strong></p>
  <dl>
    <dd><input type="radio" name="MessageType" value="Complaint">Complaint
    <input type="radio" name="MessageType" value="Problem">Problem
    <input type="radio" checked name="MessageType" value="Suggestion">Suggestion
    <input type="radio" name="MessageType" value="Praise">Praise</dd>
  </dl>
  <p><strong>What about us do you want to comment on?</strong></p>
  <dl>
    <dd><select name="Subject" size="1">
    <option selected>Web Site</option>
    <option>Interface</option>
    <option>Organization</option>
    <option>Methods Provided</option>
    <option>Employee</option>
    <option>(Other)</option>
    </select> Other:
    <input type="text" size="26" title="Will not be accepted until '(Other)' is chosen in the adjacent drop  down list" maxlength="256" name="SubjectOther"></dd>
  </dl>
  <p><strong>Enter your comments in the space provided below:</strong></p>
  <dl>
    <dd><textarea name="Comments" rows="5" cols="42"></textarea></dd>
  </dl>
  <p><strong>Tell us how to get in touch with you:</strong></p>
  <dl>
    <dd>
    <table>
      <tr>
        <td>Name</td>
        <td><input type="text" size="35" maxlength="256" name="Username"></td>
      </tr>
      <tr>
        <td>E-mail</td>
        <td><input type="text" size="35" maxlength="256" name="UserEmail"></td>
      </tr>
      <tr>
        <td>Tel</td>
        <td><input type="text" size="35" maxlength="256" name="UserTel"></td>
      </tr>
      <tr>
        <td>FAX</td>
        <td><input type="text" size="35" maxlength="256" name="UserFAX"></td>
      </tr>
    </table>
    </dd>
  </dl>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="checkbox" name="ContactRequested" value="ContactRequested"> 
    Please contact me as soon as possible regarding this matter.<p><strong>Set 
  Priority:&nbsp;&nbsp; </strong>
  <select name="Priority" size="1">
    <option>High</option>
    <option selected>Normal</option>
    <option>Low</option>
    </select></p>
  <p><input type="submit" value="Submit Comments">
  <input type="reset" value="Clear Form"></p>
</form>
<hr>
<h5>The Cogia Corp. Wholly for&nbsp; the Students, by the Students.<br>
Copyright � 2010&nbsp; [Cogia connecting answers]. All rights reserved.<br>
Revised:
<!--webbot bot="TimeStamp" s-format="%m/%d/%y" s-type="EDITED" -->.</h5>

<h5>&nbsp;</h5>

</body>

</html>