<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<link rel="File-List" href="Home%20Page_files/filelist.xml">
<link rel="stylesheet" type="text/css" href="complex/css4buttons.css" />
<title>Cogia.com the Official Website Of Cogia.</title>

<STYLE type="text/css">
BODY 
{
scrollbar-face-color: #ccffcc; scrollbar-shadow-color: "orange"; 
scrollbar-highlight-color: "yellow"; scrollbar-3dlight-color: "green"; 
scrollbar-darkshadow-color: "blue"; 
scrollbar-arrow-color: "violet"; scrollbar-track-color:indigo"
}
</STYLE>

<!--[if !mso]>
<style>
v\:*         { behavior: url(#default#VML) }
o\:*         { behavior: url(#default#VML) }
.shape       { behavior: url(#default#VML) }
</style>
<![endif]-->

<!--[if gte mso 9]>
<xml><o:shapedefaults v:ext="edit" spidmax="1027"/>
</xml><![endif]-->
</head>

<body>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="8" width="1422" height="796">
    <tr>
      <td align="right" valign="top" width="217" height="41">
<marquee scrolldelay="80" behavior="alternate" bgcolor="#CCFFFF">Cogia.</marquee></td>
      <td width="31" height="41"></td>
      <td valign="bottom" colspan="3" width="1142" height="41"><font size="5">&nbsp;<font color="#0000FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cogia.com</font> 
      the Official Website Of Cogia.</font></td>
    </tr>
    <tr>
      <td valign="top" width="217" height="739">
      
      <p align="center"><b>Navigation</b></p>
      <form action="#" name="myform1" id="myform1">
      <div class="buttons" style="height: 158; width:189">
        <p><a href="Help.htm" title="Visit our help Database">
        <img src="images/icon/Cogia.png" alt> Help Page </a><br>
        <p><a href="Feedback.htm" title="We value your feedbacks and suggestions">
        <img src="images/icon/Cogia.png" alt>Feedback </a><br>
        <p><a href="About%20Us.htm" title="Liked us? Know more about us.">
        <img src="images/icon/Cogia.png" alt> About Us </a><br>
        <p><a href="Featured%20Videos.htm" title="Featured videos of our interest">
        <img src="images/icon/Cogia.png" alt> Featured Videos </a><br>
        <p><a href="Typing%20Test%20Improved%20again.htm" title="Go here to see how good you are at typing">
        <img src="images/icon/Cogia.png" alt> Typing Test</a><br>

</div>
      <p>&nbsp;</p>
      </form>
      <table border="0" cellspacing="0" cellpadding="0" width="177">
        <tr>
          <td width="205">
          <form name="slideshow">
            <div align="center">
              <center>
              <p><b>What's On Update</b><br>
              <textarea rows="5" name="S1" cols="19" ></textarea><br>
              <input type="button" value="Take Action" name="B1" onclick="window.location=messagelinks[curmsg]"></p>
              </center>
            </div>
          </form>
          </td>
        </tr>
      </table>
      
<script type="text/javascript">
var curmsg=-1
var messages=new Array()
messages[0]="Check out more details about the people of Cogia"
messages[1]="Try out your hand at some typing test. By Cogia."
messages[2]="Surf the Archive of Date : 14-6-2011"
//add more messages as desired

var messagelinks=new Array()
messagelinks[0]="About Us.htm"
messagelinks[1]="Typing%20Test%20Improved%20again.htm"
messagelinks[2]="archive/extracted/Date 14-6-2011/Home page.htm"
//add more links as indicated by the number of messages 

function slidemessage(){
if (curmsg<messages.length-1)
curmsg++
else
curmsg=0
document.slideshow[0].value=messages[curmsg]
setTimeout("slidemessage()",4500)
}
slidemessage()
      </script>
&nbsp;</td>
      <td width="31" height="739"></td>
      <td valign="top" width="886" height="739">&nbsp; 
      <center>     
      <img src="images/Cogia%20Latest%20Logo%20(real%20Size).jpg" width="600" height="400"><hr width="40%">
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      </center>
      <form action="#" name="myform2" id="myform2">
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <!--[if gte vml 1]><v:shapetype id="_x0000_t136"
 coordsize="21600,21600" o:spt="136" adj="10800" path="m@7,l@8,m@5,21600l@6,21600e">
 <v:formulas>
  <v:f eqn="sum #0 0 10800"/>
  <v:f eqn="prod #0 2 1"/>
  <v:f eqn="sum 21600 0 @1"/>
  <v:f eqn="sum 0 0 @2"/>
  <v:f eqn="sum 21600 0 @3"/>
  <v:f eqn="if @0 @3 0"/>
  <v:f eqn="if @0 21600 @1"/>
  <v:f eqn="if @0 0 @2"/>
  <v:f eqn="if @0 @4 21600"/>
  <v:f eqn="mid @5 @6"/>
  <v:f eqn="mid @8 @5"/>
  <v:f eqn="mid @7 @8"/>
  <v:f eqn="mid @6 @7"/>
  <v:f eqn="sum @6 0 @5"/>
 </v:formulas>
 <v:path textpathok="t" o:connecttype="custom" o:connectlocs="@9,0;@10,10800;@11,21600;@12,10800"
  o:connectangles="270,180,90,0"/>
 <v:textpath on="t" fitshape="t"/>
 <v:handles>
  <v:h position="#0,bottomRight" xrange="6629,14971"/>
 </v:handles>
 <o:lock v:ext="edit" text="t" shapetype="t"/>
</v:shapetype><v:shape id="_x0000_s1028" type="#_x0000_t136" style='width:546pt;
 height:51pt' fillcolor="#9400ed" strokecolor="#eaeaea" strokeweight="1pt">
 <v:fill color2="blue" angle="-90" colors="0 #a603ab;13763f #0819fb;22938f #1a8d48;34079f yellow;47841f #ee3f17;57672f #e81766;1 #a603ab"
  method="none" type="gradient"/>
 <v:shadow on="t" type="perspective" color="silver" opacity="52429f" origin="-.5,.5"
  matrix=",46340f,,.5,,-4768371582e-16"/>
 <v:textpath style='font-family:"Arial Black";v-text-kern:t' trim="t"
  fitpath="t" string="COGIA Connecting Answers"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=947 height=91
src="Home%20Page_files/image001.gif" alt="COGIA Connecting Answers" v:shapes="_x0000_s1028"><![endif]></p>
        <hr width="40%">
        <center><h5>The Cogia Corp. Wholly for&nbsp; the Students, by the Students.<br>
        Copyright � 2010&nbsp; [Cogia connecting answers]. All rights reserved.<br>
        Revised:
        <!--webbot bot="TimeStamp" s-format="%d-%b-%Y" s-type="EDITED" startspan -->19-Jun-2011<!--webbot bot="TimeStamp" i-checksum="15949" endspan -->.</h5></center>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form>
&nbsp;</td>
      <td valign="top" width="208" height="739">
      <p></p>
      <p></p>
      <p></p>
      <p><h4>This <font color="#0000FF">Page</font> Has been visited</h4>
      </p>
      <p>&nbsp;<a target="_top"><img border="0" alt="web counter code" src="http://xyz.freelogs.com/counter/index.php?u=abhinav4848&s=7seg" ALIGN="middle" HSPACE="4" VSPACE="2"></a><script src="http://xyz.freelogs.com/counter/script.php?u=abhinav4848">
      </script> </p>
      <p><h4>times. Enjoy!!</h4>
      <h5><br>
      </td>
    </tr>
  </table>
  </center>
</div>

</h5>

</body>

</html>